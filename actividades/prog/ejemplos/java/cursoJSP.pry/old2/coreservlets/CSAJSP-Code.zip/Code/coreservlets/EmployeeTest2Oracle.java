package coreservlets;

public class EmployeeTest2Oracle {
  public static void main(String[] args) {
    String[] newArgs = { "aplcen.apl.jhu.edu", "PTE",
                         "hall", "hall", "oracle" };
    EmployeeTest2.main(newArgs);
  }
}
