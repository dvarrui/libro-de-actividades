package coreservlets;

public class ConnectionPoolTestOracle {
  public static void main(String[] args) {
    String[] newArgs = { "aplcen.apl.jhu.edu", "PTE",
                         "hall", "hall", "oracle" };
    ConnectionPoolTest.main(newArgs);
  }
}
