package coreservlets;

public class FruitTestSybase {
  public static void main(String[] args) {
    String[] newArgs = { "128.220.101.65", "605741",
                         "hall", "hall", "sybase" };
    FruitTest.main(newArgs);
  }
}
