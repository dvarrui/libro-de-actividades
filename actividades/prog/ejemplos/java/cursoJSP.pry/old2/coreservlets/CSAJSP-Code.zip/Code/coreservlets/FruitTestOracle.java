package coreservlets;

public class FruitTestOracle {
  public static void main(String[] args) {
    String[] newArgs = { "aplcen.apl.jhu.edu", "PTE",
                         "hall", "hall", "oracle" };
    FruitTest.main(newArgs);
  }
}
