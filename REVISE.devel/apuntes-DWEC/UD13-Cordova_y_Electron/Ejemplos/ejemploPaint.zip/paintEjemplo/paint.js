$(function () {

    //Creo el tablero
    for (var i=0; i<60;i++){
       $("#tablero").append('<div class="fila" id="fila' +i +'"></div>');
       for (var j=0;j<60;j++) {
           $("#fila"+i).append("<div class='celda'></div>");
       }
    }

    //Variables para saber si esta activado el pintar y el color seleccionado
    var pintar =false;
    var colorSeleccionado="";

    //Al pulsar sobre los colores, cambio el texto y almaceno el color seleccionado
    $(".color").click(function(){
        colorSeleccionado=$(this).attr("id");
        $("#estado").text(colorSeleccionado);

    });


    //Si no esta activado el modo "pintar": pinto la celda y lo activo
    $(".celda").click(function(){
        if (pintar==false) {
            pintar=true;
            $(this).css("background-color", colorSeleccionado);
        } else {
            pintar=false;
        }
        //Con el modo pintar activado, pongo evento que pinte las celdas
        if (pintar==true){
            $(".celda").mouseover(function(){
                $(this).css("background-color", colorSeleccionado);
            });
        //Con el modo pintar desactivado, quito el evento anterior
        } else {
            $(".celda").off("mouseover");
        }

    });

    //Limpio el tablero
    $("#borrar").click(function(){
        $(".celda").css("background-color", "white");
    });

});
