
/* Indico los plugins de Quokka y el html de jsdom */
({
    "plugins": [
        "jsdom-quokka-plugin",
        "quokka-jquery-loader"
    ],
    "jsdom": { "file":"index1Players.html"}
});

const $ = require("./scripts/jquery-3.3.1.min.js");


// Declaramos global con tablero de 3x3
var tablero = [
    [],
    [],
    []
];
// Declaramos el turno
var turno = 'X';
console.log(turno);

// Variable que dice si estamos en juego o no
var enJuego = true;
// Variable para indicar la dificultad
var dificultad=0;





//funcion que obtiene un numero aleatorio entre A (menor) y B (mayor)
function numeroAleatorio(A, B) {
    return Math.floor((Math.random() * (B-A) + A));
}


// Funcion que contiene la siguiente jugadad de la maquina
function obtenerTirada(){
    // Juega aleatorio
    if(dificultad==0){
        var tmpx, tmpy;
        do{
            tmpx=numeroAleatorio(0,3);
            tmpy=numeroAleatorio(0,3);
        }while(tablero[tmpx][tmpy]);
        return [tmpx,tmpy];
    }
    // Intenta jugar a ganar
    else if (dificultad==1){
        // Recorro el tablero buscando casillas libres

        for(var i=0;i<3;i++){
            for(var j=0;j<3;j++){
                if(tablero[i][j]!='X' && tablero[i][j]!='O'){

                }
            }
        }

    }
}


// Funcion que recibe un turno y comprueba si se ha ganado o no
function haGanado(t) {

    /**
     * 0,0 0,1 0,2
     * 1,0 1,1 1,2
     * 2,0 2,1 2,2
     *      * 
     */

    // Como son 8 casos, los ponemos a mano
    if (tablero[0][0] == t && tablero[0][0] == tablero[0][1] && tablero[0][0] == tablero[0][2])
        return true;
    if (tablero[1][0] == t && tablero[1][0] == tablero[1][1] && tablero[1][0] == tablero[1][2])
        return true;
    if (tablero[2][0] == t && tablero[2][0] == tablero[2][1] && tablero[2][0] == tablero[2][2])
        return true;

    if (tablero[0][0] == t && tablero[0][0] == tablero[1][0] && tablero[0][0] == tablero[2][0])
        return true;
    if (tablero[0][1] == t && tablero[0][1] == tablero[1][1] && tablero[0][1] == tablero[2][1])
        return true;
    if (tablero[0][2] == t && tablero[0][2] == tablero[1][2] && tablero[0][2] == tablero[2][2])
        return true;

    if (tablero[0][0] == t && tablero[0][0] == tablero[1][1] && tablero[0][0] == tablero[2][2])
        return true;

    if (tablero[0][2] == t && tablero[0][2] == tablero[1][1] && tablero[0][2] == tablero[2][0])
        return true;


    // Si no se cumple ningun caso no hay victoria
    return false;


}

// Funcion que se ejecuta cuando se carga la pagina completamente

$(document).ready(function () {
    // Inicializamos turno y tablero
    turno = 'X';
    tablero = [
        [],
        [],
        []
    ];

    // Inicializamos a vacio el tablero
    for (var i = 0; i < 3; i++) {
        for (var j = 0; j < 3; j++) {
            tablero[i][j];
        }
    }

    // Indicamos quien tiene el turno actualmente
    $("#pTurno").text("Turno jugador " + turno);

    // Por cada  fila
    for (var i = 1; i <= 3; i++) {

        // para cada columna
        for (var j = 1; j <= 3; j++) {

            // Ponemos la imagen vacia de forma inicial
            $("#c" + i + "" + j).children().first().attr("src", "assets/img/vacio.png");

            // Evento por cada jugador y carta
            $("#c" + i + "" + j).click(function () {

                // Si no estamos jugando, no se hace nada...
                if (enJuego == false) {
                    return;
                }

                // Para saber el jugador, extraemos el texto del id las posiciones de cada jugador
                // y restamos 1 para la equivalencia con el array del tabalero
                valoriExtraidoID = parseInt($(this).attr("id").slice(-2, -1)) - 1;
                valorjExtraidoID = parseInt($(this).attr("id").slice(-1)) - 1;



                // Si es su turno y no esta ya marcada, podemos marcarla
                if (tablero[valoriExtraidoID][valorjExtraidoID] != 'X' && tablero[valoriExtraidoID][valorjExtraidoID] != 'O') {
                    // Marcamos el tablero
                    tablero[valoriExtraidoID][valorjExtraidoID] = turno;
                    // Ponemos la imagen
                    $(this).children().first().attr("src", "assets/img/" + turno + ".png");

                    // Comprobamos si ha ganado
                    if (haGanado(turno)) {
                        // Si ha ganado, dejamos de estar en juego y modificamos el mensaje
                        // del turno, indicando quien ha ganado
                        enJuego = false;
                        $("#pTurno").text("El ganador es " + turno);
                        // Ponemos un borde rojo para destacar
                        $("#pTurno").css({
                            "border-color": "red",
                            "border-width": "1px",
                            "border-style": "solid"
                        });
                        // Finalizamos
                        return;
                    }

                    // Cambiamos de turno. Suponemos la maquina es el O
                    turno = "O";
                    // Obtenemos las posiciones de la tirada
                    var pos = obtenerTirada();
                    tablero[pos[0]][pos[1]] = turno;
                    // Ponemos la imagen de la tirada de la maquina
                    $("#c"+(pos[0]+1)+""+(pos[1]+1)).children().first().attr("src", "assets/img/" + turno + ".png");
                   
                    // Comprobamos si tras tirar la maquina ha ganado
                    if (haGanado(turno)) {
                        // Si ha ganado, dejamos de estar en juego y modificamos el mensaje
                        // del turno, indicando quien ha ganado
                        enJuego = false;
                        $("#pTurno").text("El ganador es " + turno);
                        // Ponemos un borde rojo para destacar
                        $("#pTurno").css({
                            "border-color": "red",
                            "border-width": "1px",
                            "border-style": "solid"
                        });
                        // Finalizamos
                        return;
                    }
                    // Volvemos a poner el turno
                    turno = "X";

                    // Establecemos texto del turno
                    $("#pTurno").text("Turno jugador " + turno);
                }
            });
        }
    }


});